To install the pack, right click "Team Fortress 2" in your steam library list and click "Properties". In the "Local Files" tab, click "Browse Local Files". From here, go into the "tf" folder and extract "contents.zip" to this folder. Then follow the steps below.

The pack currently only censors the voice lines and disables text chat. To disable blood and gore and remove voice chat, follow these steps:

Go into your Team Fortress 2 properties like you did before, but in the "General" tab, click "Set Launch Options" and paste in the text below.
-sillygibs +violence_ablood 0 +violence_agibs 0 +violence_hblood 0 +violence_hgibs 0

Next, in Options > Voice, set both the "Voice transmit volume" and "Voice recieve volume" sliders to the very left.

You're done! Enjoy the pack.






TF2 E10+ Created by Double_Felix


